/**
 * scene based application main controller
 */
$class('mobello1.MainController').extend(tau.ui.SceneController).define({
	MainController: function (opts){
		
	},

	init: function (){
		
	},
	
	destroy: function (){
		
	}
});