function initScene() {
	var scene = this.getScene();
	var button1 = new tau.ui.Button({label : {normal: 'Button'}});
	scene.add(button1);
	var button2 = new tau.ui.Button({label : {normal: 'Button'}});
	scene.add(button2);
}