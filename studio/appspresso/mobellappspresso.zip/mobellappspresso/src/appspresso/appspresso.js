/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 *
 * This javascript will generate from the Appspresso Studio on build time.
 * It should not be modified by hand.
 */